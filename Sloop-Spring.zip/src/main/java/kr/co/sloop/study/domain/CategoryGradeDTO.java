package kr.co.sloop.study.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CategoryGradeDTO {
    private String CategoryGradeName;
    private String CategoryGradeCode;
}
