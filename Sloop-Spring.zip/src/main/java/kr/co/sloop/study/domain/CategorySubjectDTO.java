package kr.co.sloop.study.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CategorySubjectDTO {
    private String CategorySubjectName;
    private String CategorySubjectCode;
}
